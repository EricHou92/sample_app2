class Administrator < ActiveRecord::Base
end
